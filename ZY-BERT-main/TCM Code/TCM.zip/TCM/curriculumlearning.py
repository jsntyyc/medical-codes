import os
import json
import pandas as pd
import torch
from transformers import AutoTokenizer, AutoModel
import matplotlib
import matplotlib.pyplot as plt
from tqdm import tqdm
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
import numpy as np

# ----------------------------
# 配置设备和模型参数
# ----------------------------
os.environ["CUDA_VISIBLE_DEVICES"] = "0,1,2,3"  # 指定使用的 GPU
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# 预训练模型路径（这里采用 RoBERTa 模型）
model_name = "/mnt/nvme2/yyc/TCM/ZY-BERT"

# ----------------------------
# 加载数据（train.json）
# ----------------------------
input_path = "/mnt/nvme2/yyc/TCM/TCM_SD_train_dev/trainV2.json"
data = []
with open(input_path, "r", encoding="utf-8") as f:
    for line in f:
        data.append(json.loads(line.strip()))

# 将数据转换为 DataFrame（假设每个样本已包含 "TEXT" 字段）
df = pd.DataFrame(data)
texts = df["TEXT"].tolist()

# ----------------------------
# 加载预训练模型和 tokenizer，并计算文本嵌入（使用 CLS 向量）
# ----------------------------
tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModel.from_pretrained(model_name)
if torch.cuda.device_count() > 1:
    print(f"Using {torch.cuda.device_count()} GPUs for parallel processing.")
    model = torch.nn.DataParallel(model)
model.to(device)
model.eval()

embeddings = []
batch_size = 1024  # 可根据显存调整
for i in tqdm(range(0, len(texts), batch_size), desc="Embedding Progress"):
    batch_texts = texts[i:i + batch_size]
    inputs = tokenizer(batch_texts, padding=True, truncation=True, max_length=512, return_tensors="pt")
    inputs = {k: v.to(device) for k, v in inputs.items()}
    with torch.no_grad():
        outputs = model(**inputs)
        # 使用 CLS 向量（位置 0）
        cls_embeddings = outputs.last_hidden_state[:, 0, :]
        embeddings.append(cls_embeddings.cpu())
embeddings = torch.cat(embeddings, dim=0)
print("Embeddings shape:", embeddings.shape)
embeddings_np = embeddings.numpy()

# ----------------------------
# PCA 降维并可视化
# ----------------------------
pca = PCA(n_components=2)
X_pca = pca.fit_transform(embeddings_np)

plt.figure(figsize=(12, 10))
plt.scatter(X_pca[:, 0], X_pca[:, 1], alpha=0.6, s=20)
plt.title("PCA Visualization of ZY-BERT Embeddings", fontsize=16)
plt.xlabel("PCA Dimension 1", fontsize=14)
plt.ylabel("PCA Dimension 2", fontsize=14)
plt.grid(True, linestyle="--", alpha=0.5)
plt.savefig("pca_visualization_train.png", dpi=300)
# plt.show()

# ----------------------------
# KMeans 聚类：将样本聚成 3 类
# ----------------------------
n_clusters = 3
kmeans = KMeans(n_clusters=n_clusters, random_state=42)
cluster_labels = kmeans.fit_predict(embeddings_np)  # 聚类标签

# ----------------------------
# 可视化聚类结果
# ----------------------------
plt.figure(figsize=(12, 10))
for cluster_id in range(n_clusters):
    cluster_points = X_pca[cluster_labels == cluster_id]
    plt.scatter(cluster_points[:, 0], cluster_points[:, 1],
                label=f"Cluster {cluster_id}", alpha=0.7, s=20)
plt.scatter(pca.transform(kmeans.cluster_centers_)[:, 0],
            pca.transform(kmeans.cluster_centers_)[:, 1],
            c="red", marker="x", s=100, label="Centroids")
plt.title("KMeans Clustering of ZY-BERT Embeddings (PCA)", fontsize=16)
plt.xlabel("PCA Dimension 1", fontsize=14)
plt.ylabel("PCA Dimension 2", fontsize=14)
plt.legend(fontsize=12)
plt.grid(True, linestyle="--", alpha=0.5)
plt.savefig("clustering_result.png", dpi=300)
# plt.show()

# ----------------------------
# 直接将聚类标签打到数据中，不构造映射
# ----------------------------
df["difficulty"] = cluster_labels  # 每个样本的 difficulty 字段即为其聚类标签（0, 1, 2）

# 保存结果到新 JSON 文件（每行一个 JSON 记录）
output_path = "/mnt/nvme2/yyc/TCM/TCM_SD_train_dev/train_with_difficultyV2.json"
with open(output_path, "w", encoding="utf-8") as fout:
    for _, row in df.iterrows():
        fout.write(json.dumps(row.to_dict(), ensure_ascii=False) + "\n")
print(f"Updated dataset with difficulty saved to {output_path}")

# 输出每个聚类类别的样本数量
print(df["difficulty"].value_counts())
