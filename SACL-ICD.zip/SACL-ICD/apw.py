#!/usr/bin/env python
# coding: utf-8

import os
import math
import argparse
import numpy as np
import pandas as pd
import torch
from tqdm import tqdm
from sklearn.cluster import KMeans
from torch.utils.data import Dataset, DataLoader
from transformers import AutoTokenizer, AutoModelForSequenceClassification, AdamW
from torch.nn import BCEWithLogitsLoss

class FeatherICDDataset(Dataset):
    """
    读取 Feather 文件，假定其中有两列：
      - 'TEXT': 文本字段
      - 'labels': 每行一个 Python 列表，包含该条记录对应的 ICD code 索引
    你可以根据实际列名调整这两项。
    """
    def __init__(self, feather_path, tokenizer, max_length, num_labels):
        self.df = pd.read_feather(feather_path)
        self.tokenizer = tokenizer
        self.max_length = max_length
        self.num_labels = num_labels

    def __len__(self):
        return len(self.df)

    def __getitem__(self, idx):
        row = self.df.iloc[idx]

        text = row['text']
        labels = row['target']   # e.g. [23, 45, 102]
        enc = self.tokenizer(
            text,
            truncation=True,
            padding='max_length',
            max_length=self.max_length,
            return_tensors='pt'
        )
        # multi-hot
        multi_hot = torch.zeros(self.num_labels, dtype=torch.float)
        multi_hot[labels] = 1.0

        return idx, \
               enc['input_ids'][0], \
               enc['attention_mask'][0], \
               multi_hot

def parse_args():
    p = argparse.ArgumentParser(description="PLM-ICD 第一阶段训练 + APW + KMeans 难度打标")
    p.add_argument('--input_feather',   type=str, default='/mnt/nvme2/yyc/medical-coding/files/data/mimiciii_50/mimiciii_cluster3.feather',
                   help='输入数据 Feather 文件路径')
    p.add_argument('--output_feather',  type=str, default='/mnt/nvme2/yyc/medical-coding/files/data/mimiciii_50/mimiciii_cluster_with_difficulty0620.feather',
                   help='输出带 difficulty 列的 Feather 路径')
    p.add_argument('--model_name_or_path', type=str, default='/mnt/nvme2/yyc/PLM-ICD2/RoBERTa-base-PM-M3-Voc-distill-align-hf',
                   help='预训练 PLM-ICD 模型名或本地路径')
    p.add_argument('--num_labels',      type=int, default=8929,
                   help='ICD 标签总数')
    p.add_argument('--max_length',      type=int, default=512,
                   help='最大序列长度')
    p.add_argument('--batch_size',      type=int, default=32)
    p.add_argument('--learning_rate',   type=float, default=5e-5)
    p.add_argument('--num_epochs',      type=int, default=4)
    p.add_argument('--easy_quantile',   type=float, default=20.0,
                   help='每轮判为易样本的损失百分位 (0–100)')
    p.add_argument('--q',               type=float, default=1.0,
                   help='APW 损失平衡因子 q')
    p.add_argument('--lambda_coef',     type=float, default=0.5,
                   help='拼接 first_easy 时的系数 λ')
    p.add_argument('--mu_coef',         type=float, default=0.5,
                   help='拼接 omega 时的系数 μ')
    p.add_argument('--seed',            type=int, default=42)
    return p.parse_args()

def set_seed(seed: int):
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)

def main():
    args = parse_args()
    set_seed(args.seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # 1) 加载 Tokenizer & 模型
    tokenizer = AutoTokenizer.from_pretrained(args.model_name_or_path)
    model = AutoModelForSequenceClassification.from_pretrained(
        args.model_name_or_path,
        num_labels=args.num_labels,
        problem_type="multi_label_classification"
    )
    model.to(device)
    optimizer = AdamW(model.parameters(), lr=args.learning_rate)
    loss_fct = BCEWithLogitsLoss(reduction='none')

    # 2) 构造 Dataset & DataLoader
    dataset = FeatherICDDataset(
        args.input_feather,
        tokenizer,
        args.max_length,
        args.num_labels
    )
    dataloader = DataLoader(
        dataset,
        batch_size=args.batch_size,
        shuffle=True,
        pin_memory=True
    )

    N = len(dataset)
    # APW 初始化
    omega = np.ones(N, dtype=np.float64) / N
    first_easy = np.full(N, np.inf, dtype=np.float32)

    # 3) APW 加权训练：第一阶段
    for epoch in range(1, args.num_epochs + 1):
        model.train()
        epoch_losses = np.zeros(N, dtype=np.float32)

        for idxs, input_ids, attn_mask, labels in tqdm(dataloader,
                                                      desc=f"Epoch {epoch}"):
            idxs = idxs.numpy()
            input_ids = input_ids.to(device)
            attn_mask = attn_mask.to(device)
            labels = labels.to(device)

            optimizer.zero_grad()
            outputs = model(input_ids=input_ids,
                            attention_mask=attn_mask)
            logits = outputs.logits            # [B, C]
            loss_all = loss_fct(logits, labels)  # [B, C]
            loss_per_sample = loss_all.mean(dim=1)  # [B]

            # 加权平均并反向
            w_batch = torch.from_numpy(omega[idxs]).to(device)
            loss = (loss_per_sample * w_batch).mean()
            loss.backward()
            optimizer.step()

            # 记录原始 loss 用于 APW 更新
            epoch_losses[idxs] = loss_per_sample.detach().cpu().numpy()

        # APW 更新
        e = np.percentile(epoch_losses, args.easy_quantile)
        beta = np.where(epoch_losses <= e, +1.0, -1.0)

        # 记录首次易样本 epoch
        newly = (beta == +1.0) & (first_easy == np.inf)
        first_easy[newly] = float(epoch)

        rho = omega[beta < 0].sum()
        rho = float(np.clip(rho, 1e-6, 1 - 1e-6))
        alpha = (1.0 / args.q) * math.log((1 - rho) / rho)

        omega = omega * np.exp(-alpha * beta)
        omega = omega / omega.sum()

        easy_pct = (beta == +1.0).sum() / N
        print(f"Epoch {epoch}/{args.num_epochs} — "
              f"e={e:.4f}, easy%={easy_pct:.1%}, ρ={rho:.4f}, α={alpha:+.4f}")

    # 4) 提取 Encoder CLS 表示
    model.eval()
    # 获取底层 encoder 对象
    encoder = model.base_model if hasattr(model, 'base_model') else model.bert
    hidden_size = encoder.config.hidden_size
    X = np.zeros((N, hidden_size), dtype=np.float32)

    with torch.no_grad():
        for idxs, input_ids, attn_mask, _ in tqdm(DataLoader(dataset,
                                                              batch_size=args.batch_size),
                                                  desc="Extract CLS"):
            idxs = idxs.numpy()
            input_ids = input_ids.to(device)
            attn_mask = attn_mask.to(device)

            out = encoder(input_ids=input_ids,
                          attention_mask=attn_mask,
                          return_dict=True)
            cls_emb = out.last_hidden_state[:, 0, :].cpu().numpy()  # [B, hidden]
            X[idxs] = cls_emb

    # 5) 构造聚类特征并 KMeans
    # 归一化 first_easy & omega 到 [0,1]
    L = first_easy.copy()
    L[np.isinf(L)] = args.num_epochs + 1
    L_norm = (L - L.min()) / (L.max() - L.min() + 1e-8)
    W_norm = (omega - omega.min()) / (omega.max() - omega.min() + 1e-8)

    Z = np.concatenate([
        X,
        (args.lambda_coef * L_norm).reshape(-1, 1),
        (args.mu_coef     * W_norm).reshape(-1, 1)
    ], axis=1)

    kmeans = KMeans(n_clusters=3, random_state=args.seed)
    clusters = kmeans.fit_predict(Z)

    # 6) 根据 avg(first_easy) 排序簇，并映射为 easy/middle/hard
    cluster_ids = np.unique(clusters)
    avg_L = {k: L_norm[clusters == k].mean() for k in cluster_ids}
    ordered = sorted(cluster_ids, key=lambda k: avg_L[k])
    mapping = {
        ordered[0]: "easy",
        ordered[1]: "middle",
        ordered[2]: "hard"
    }

    # 7) 保存结果到新的 Feather
    df = pd.read_feather(args.input_feather)
    df['difficulty'] = [mapping[c] for c in clusters]
    df.to_feather(args.output_feather)
    print(f"✔ 已保存带 difficulty 标签的文件：{args.output_feather}")

if __name__ == "__main__":
    main()
